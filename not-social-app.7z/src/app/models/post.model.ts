export class Post {
	id: number | any;
	title: string | any;
	owner: string | any;
	body: string | any;
	image: string | any =
		'https://upload.wikimedia.org/wikipedia/commons/thumb/c/cf/Angular_full_color_logo.svg/langfr-1024px-Angular_full_color_logo.svg.png';
}
