export class Comment {
	post_id: number | any;
	body: string | any;
	owner: string | any;
}
