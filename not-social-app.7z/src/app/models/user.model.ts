export class User {
	id: number | any;
	username: string | any;
	password: string | any;
}
